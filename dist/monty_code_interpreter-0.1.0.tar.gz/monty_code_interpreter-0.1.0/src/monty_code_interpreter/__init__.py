"""DSPy CodeInterpreter implementation using Monty."""

from monty_code_interpreter.interpreter import MontyInterpreter

__all__ = ["MontyInterpreter"]
